# AWS VPN Client — OpenVPN3 Modifications

These patches are Amazon Web Services modifications to OpenVPN 3,
used in the AWS VPN Client application.

## Base version

OpenVPN 3 version 3.11.5
https://github.com/OpenVPN/openvpn3/releases/tag/release/3.11.5

## Applying patches

Download the source at the base version, then apply all patches in order:

```bash
git clone --branch release/3.11.5 https://github.com/OpenVPN/openvpn3.git
cd openvpn3
for patch in /path/to/patches/*.patch; do patch -p1 < "$patch"; done
```

Patches are numbered to ensure correct application order.
